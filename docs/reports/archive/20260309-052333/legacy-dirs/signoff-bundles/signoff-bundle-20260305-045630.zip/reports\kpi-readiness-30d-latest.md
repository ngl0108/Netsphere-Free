# KPI Readiness Evidence

- Generated (UTC): `2026-03-04 19:02:49`
- Readiness Status: `critical`
- Required Checks: `18`
- Pass / Fail / Unknown: `7` / `8` / `3`

## Scope

- site_id: `-`
- discovery_days: `30`
- discovery_limit: `300`
- require_sample_minimums: `True`

## Query Params

- discovery_days: `30`
- discovery_limit: `300`
- require_sample_minimums: `True`
- sample_min_autonomy_actions_executed: `20`
- sample_min_autonomy_issues_created: `20`
- sample_min_change_events: `60`
- sample_min_discovery_jobs: `30`
- sample_min_northbound_deliveries: `500`

## Sample Evidence

| Metric | Observed | Threshold |
|---|---:|---:|
| `autonomy_actions_executed` | `0` | `20` |
| `autonomy_issues_created` | `11` | `20` |
| `change_events` | `0` | `60` |
| `discovery_jobs` | `18` | `30` |
| `northbound_deliveries` | `0` | `500` |

## Check Results

| Check ID | Status | Value | Threshold | Required | Source |
|---|---|---:|---:|---|---|
| `plug_scan.first_map_p50_seconds` | `unknown` | `-` | `300` | `True` | `discovery.kpi.summary` |
| `plug_scan.first_map_p95_seconds` | `unknown` | `-` | `900` | `True` | `discovery.kpi.summary` |
| `plug_scan.auto_reflection_rate_pct` | `fail` | `2.19` | `75.00` | `True` | `discovery.kpi.summary` |
| `plug_scan.false_positive_rate_pct` | `fail` | `20.00` | `10.00` | `True` | `discovery.kpi.summary` |
| `change.success_rate_pct` | `pass` | `100.00` | `98.00` | `True` | `sdn.dashboard.stats.change_kpi` |
| `change.failure_rate_pct` | `pass` | `0.00` | `1.00` | `True` | `sdn.dashboard.stats.change_kpi` |
| `change.rollback_p95_ms` | `unknown` | `-` | `180000` | `True` | `sdn.dashboard.stats.change_kpi` |
| `change.trace_coverage_pct` | `pass` | `100.00` | `100.00` | `True` | `sdn.dashboard.stats.change_kpi` |
| `autonomy.auto_action_rate_pct` | `fail` | `0.00` | `60.00` | `True` | `sdn.dashboard.stats.autonomy_kpi` |
| `autonomy.operator_intervention_rate_pct` | `pass` | `0.00` | `40.00` | `True` | `sdn.dashboard.stats.autonomy_kpi` |
| `autonomy.mttd_improvement_pct` | `unknown` | `-` | `30.00` | `False` | `sdn.dashboard.stats.autonomy_kpi` |
| `autonomy.mttr_improvement_pct` | `unknown` | `-` | `40.00` | `False` | `sdn.dashboard.stats.autonomy_kpi` |
| `northbound.success_rate_pct` | `pass` | `100.00` | `95.00` | `True` | `sdn.dashboard.stats.northbound_kpi` |
| `northbound.p95_attempts` | `pass` | `0` | `3` | `True` | `sdn.dashboard.stats.northbound_kpi` |
| `northbound.failed_24h` | `pass` | `0` | `5` | `True` | `sdn.dashboard.stats.northbound_kpi` |
| `sample.discovery.jobs_count` | `fail` | `18` | `30` | `True` | `ops.kpi.readiness.sample_gate` |
| `sample.change.events` | `fail` | `0` | `60` | `True` | `ops.kpi.readiness.sample_gate` |
| `sample.northbound.deliveries` | `fail` | `0` | `500` | `True` | `ops.kpi.readiness.sample_gate` |
| `sample.autonomy.issues_created` | `fail` | `11` | `20` | `True` | `ops.kpi.readiness.sample_gate` |
| `sample.autonomy.actions_executed` | `fail` | `0` | `20` | `True` | `ops.kpi.readiness.sample_gate` |
